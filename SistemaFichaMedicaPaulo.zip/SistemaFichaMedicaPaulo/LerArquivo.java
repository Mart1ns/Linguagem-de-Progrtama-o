import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LerArquivo {
    public static void ler(String arquivo) throws FileNotFoundException {

        try {
            BufferedReader reader = new BufferedReader(new FileReader(arquivo));

            String linha;
            while ((linha = reader.readLine()) != null) {
                System.out.println(linha);
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
