import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class InterfaceUsuario {
    private Scanner scanner = new Scanner(System.in);

    private Paciente solicitacaoDadosPaciente() {
        System.out.println("Digite os dados do paciente");
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("Idade: ");
        int idade = scanner.nextInt();
        System.out.print("Gênero: ");
        String genero = scanner.next();
        System.out.print("Altura: ");
        double altura = scanner.nextDouble();
        System.out.print("Peso: ");
        double peso = scanner.nextDouble();

        Paciente paciente = new Paciente(nome, genero, idade, altura, peso);

        return paciente;
    }

    public void exibirMenuPrincipal() {
        System.out.println("Ficha médica");
        System.out.println("1. Criar ficha médica");
        System.out.println("2. Buscar ficha médica");
        System.out.println("3. Atualizar ficha médica");
        System.out.print("Informe o dígito da opção desejada: ");

        int opcao = scanner.nextInt();

        switch (opcao) {
            case 1:
                Paciente paciente = solicitacaoDadosPaciente();
                try {
                    CriarArquivo.criarArquivo(paciente);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                break;

            case 2:
                System.out.print("Digite o nome completo do paciente: ");
                String nome = scanner.next();
                String arquivo = ProcurarArquivo.procurarArquivo(nome);

                if (arquivo != null) {
                    try {
                        LerArquivo.ler(arquivo);
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    System.out.println("O paciente não existe nos registros.");
                }
                break;

            case 3:
                System.out.print("Digite o nome completo do paciente: ");
                nome = scanner.next();

                System.out.print("Qual dado deve ser editado? ");
                String dado = scanner.next();

                arquivo = ProcurarArquivo.procurarArquivo(nome);

                if (arquivo != null) {
                    if (dado.equalsIgnoreCase("Nome")) {
                        System.out.println("O nome não pode ser editado.");
                    } else if (dado.equalsIgnoreCase("Idade") || dado.equalsIgnoreCase("Gênero") ||
                            dado.equalsIgnoreCase("Peso") || dado.equalsIgnoreCase("Altura")) {
                        System.out.print("Novo valor: ");
                        Object novaInformacao = scanner.next();
                        EditarArquivo.editar(arquivo, dado, novaInformacao);
                    } else {
                        System.out.println("Esse dado não existe.");
                    }
                } else {
                    System.out.println("O paciente não existe nos registros.");
                }
                break;

            default:
                System.out.println("Opção inválida.");
                break;
        }
    }

}
