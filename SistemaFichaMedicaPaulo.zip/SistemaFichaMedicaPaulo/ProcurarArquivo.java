import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ProcurarArquivo {
    public static String procurarArquivo(String nome){
        nome = nome.replaceAll("\\s+","");
        String caminhoArquivo = CriarArquivo.caminho +  "\\FichaMedica_" + nome + ".txt" ;
        Path caminho = Paths.get(caminhoArquivo);
        if(Files.exists(caminho))
            return (caminhoArquivo);

        return null;
    }
}

