public class Paciente {

    private String nome;
    private String genero;
    private int idade;
    private double altura;
    private double peso;

    public Paciente(String nome, String genero, int idade, double altura, double peso) {
        this.nome = nome;
        this.genero = genero;
        this.idade = idade;
        this.altura = altura;
        this.peso = peso;
    }

    public String getNome() {
        return nome;
    }

    public String getGenero() {
        return genero;
    }

    public int getIdade() {
        return idade;
    }


    public double getAltura() {
        return altura;
    }

    public double getPeso() {
        return peso;
    }

}
