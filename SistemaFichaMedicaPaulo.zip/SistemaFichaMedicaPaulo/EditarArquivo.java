import java.io.*;

public class EditarArquivo {
    public static void editar(String arquivoo, String tipoDado, Object novoValor) {
        try {
            File arquivo = new File(arquivoo);
            File arquivoBak = new File(arquivoo + ".txt");

            BufferedReader bufferedReader = new BufferedReader(new FileReader(arquivo));
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(arquivoBak));

            String linha;
            while ((linha = bufferedReader.readLine()) != null) {
                if (linha.toLowerCase().startsWith(tipoDado.toLowerCase() + ":")) {
                    if (tipoDado.equalsIgnoreCase("nome")) {
                        bufferedWriter.write(linha);
                    } else {
                        linha = tipoDado + ": " + novoValor;
                        bufferedWriter.write(linha);
                    }
                } else {
                    bufferedWriter.write(linha);
                }
                bufferedWriter.newLine();
            }

            bufferedReader.close();
            bufferedWriter.close();

            if (arquivo.delete() && arquivoBak.renameTo(arquivo)) {
                System.out.println("Ficha médica atualizada com sucesso!");
            } else {
                System.out.println("Erro ao atualizar a ficha médica.");
            }

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

}
