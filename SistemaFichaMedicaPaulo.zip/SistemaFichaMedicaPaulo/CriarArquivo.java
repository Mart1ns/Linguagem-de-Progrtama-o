import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class CriarArquivo {
    static File caminho = new File("C:\\Users\\Administrador\\Documentos\\");
    public static void criarArquivo(Paciente paciente) throws IOException{


        try {
            String arquivo = "FichaMedica_" + paciente.getNome().replaceAll("\\s+", "") + ".txt";

            caminho.mkdir();

            File ficha = new File(caminho, arquivo);
            ficha.createNewFile();

            FileWriter fileWriter = new FileWriter(ficha, false);

            PrintWriter printWriter = new PrintWriter(fileWriter);

            printWriter.println("Nome completo: " + paciente.getNome());
            printWriter.println("Gênero: " + paciente.getGenero());
            printWriter.println("Idade: " + paciente.getIdade());
            printWriter.println("Altura: " + paciente.getAltura());
            printWriter.println("Peso: " + paciente.getPeso());

            printWriter.flush();

            printWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
